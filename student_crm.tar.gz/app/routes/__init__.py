# Namespace for blueprints
